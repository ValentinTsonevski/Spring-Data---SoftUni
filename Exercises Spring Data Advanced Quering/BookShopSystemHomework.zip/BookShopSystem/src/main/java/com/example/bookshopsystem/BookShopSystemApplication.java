package com.example.bookshopsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookShopSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookShopSystemApplication.class, args);
    }

}
